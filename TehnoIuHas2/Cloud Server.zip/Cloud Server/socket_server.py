import socket
import threading
import utilites 
import time

HOST = 'localhost' # Standard loopback interface address (localhost)
PORT = 25565  # Port to listen on (non-privileged ports are > 1023)

####################################################################
# with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
# 	s.bind((HOST, PORT))
# 	s.listen()
# 	while True:
# 		conn, addr = s.accept()
# 		with conn:
# 		print('Connected by', addr)
# 		while True:
# 		data = conn.recv(1024)
# 		if data.decode('utf-8') == 'close':
# 		break
# 		conn.sendall(data)
#####################################################################


stop = False


def socket_loop(HOST,PORT):
	print("-------------------SOCKET SERVER STARTED-------------------")
	with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
		s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
		s.bind((HOST, PORT))
		s.listen()
		print("[SERVER STARTED]")
		quit = False 
		while not quit:
			client, addr = s.accept()
			print("client node Connected")
			if utilites.commands[-1] != None:
				client.send(utilites.commands[-1].encode())
			
			client.close()
			quit = True


socket_server = threading.Thread(target=socket_loop,args = [HOST, PORT])
socket_server.start()
if stop == True:
	print("-------------------SOCKET SERVER STopeD-------------------")
	socket_server.join()		
		
			
			
	