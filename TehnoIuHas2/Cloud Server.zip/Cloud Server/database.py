#----------------------
#DATABASE
#TABLES AVALIBLE:
#----------------------
#	logs:
#		log
#		date
#----------------------
#	temperture_humedity:
#		temperture
#		humedity
#		t_out
#		h_out
#		date
#----------------------

#initialize comunication with database
#connection = sqlite3.connect("smart_home.db")
#cursor = connection.cursor()

#saving and closing conection with database
#connection.commit()
#connection.close()

#FOR CRETING SHEETS with TABLES
#cursor.execute("CREATE TABLE temperture_humedity (temperture REAL, humedity REAL, t_out REAL, h_out REAL, date TEXT)")

import sqlite3

#LIST TABLES
def tables_in_sqlite_db(conn):
    cursorl = conn.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = [
        v[0] for v in cursorl.fetchall()
        if v[0] != "sqlite_sequence"
    ]
    cursorl.close()
    return tables

#INSERTING DATA IN DATABASES
def insert(table, row):
	connection = sqlite3.connect("smart_home.db")
	tables = tables_in_sqlite_db(connection)
	if table in tables:
		#form for inserting
		form = "INSERT INTO {} VALUES ({})"
		cursor = connection.cursor()
		cursor.execute(form.format(table,row))
		connection.commit()
		connection.close()

#EXTRACTING DATA FROM DATABASE
def extracting(table, columns):
	connection = sqlite3.connect("smart_home.db")
	cursor = connection.cursor()
	tables = tables_in_sqlite_db(connection)
	if table in tables:
		#form for extracting data
		form = "SELECT {} FROM {}"
		cursor = connection.cursor()
		rows = cursor.execute(form.format(columns, table)).fetchall()
		connection.commit()
		connection.close()
		return rows
