from flask_app import app
#import socket_server 


if __name__ == '__main__':
	app.run(debug=False, port =5001, host= '0.0.0.0',)