import threading
import time

x = False

def loop():
	while not x:
		print("------------")
		time.sleep(1)
	print("Hello World")

y = threading.Thread(target=loop)
y.start()
time.sleep(5)
x = True
time.sleep(5)
y.join()
