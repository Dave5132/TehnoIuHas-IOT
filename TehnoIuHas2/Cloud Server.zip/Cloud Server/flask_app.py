import database
#import utilites
from flask import Flask
from flask import request
from flask import jsonify

app = Flask(__name__)

commands = [] 

@app.route('/')
def general():
    return 'Cloud used for smart Home!'

@app.route('/uploud', methods=["POST"])
def uploud():
	request.get_json()
	content= request.json
	if content['type'] == "stats":
		database.insert('temperture_humedity',content['row'])
		return "Succes"
	elif content['type'] == "logs":
		database.insert('logs', content['row'])
		return "Succes"
	else:
		return "Error"

@app.route('/retrive/<command>')
def retrive(command):
	if command == "stats":
		result = database.extracting('temperture_humedity','temperture, humedity, t_out, h_out, date')
		return jsonify({'result':result})
	elif command == 'logs':
		result = database.extracting('logs','log, date')
		return jsonify({'result':result})

@app.route('/command/<command>')
def command(command):
	if command == "check":
		return jsonify({"commands": commands})
		commands.clear()
	else:
		command.append(command)
		return jsonify({"commands": []})
