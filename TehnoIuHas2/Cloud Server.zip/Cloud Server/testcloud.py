import requests
#res = requests.post('http://localhost:5001/uploud', json={"type":"logs","row":"'Test uploud funxction','2020-07-11-22:51'"})
print("Succes!!!")

res = requests.get('http://localhost:5001/retrive', json = {'type':"logs"})
print(res.json())