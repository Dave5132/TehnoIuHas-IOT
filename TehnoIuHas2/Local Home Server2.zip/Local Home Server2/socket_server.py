import socket
import threading
import time

HOST = 'localhost' # Standard loopback interface address (localhost)
PORT = 25565  # Port to listen on (non-privileged ports are > 1023)

# stop = False

# socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# 	s.connect((HOST, PORT))
# 	while not stop:
# 		data = s.recv(1024)
# 		if data.decode('utf-8') != '' or data != None:
# 			print(data.decode('utf-8'))


def socket_loop():
	with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
		s.connect((HOST, PORT))
		data = s.recv(1024)
		print(data.decode('utf-8'))


if __name__ == '__main__':
	socket_loop()
