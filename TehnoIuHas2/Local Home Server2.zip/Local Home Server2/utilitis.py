commands = []
 
stats = {}