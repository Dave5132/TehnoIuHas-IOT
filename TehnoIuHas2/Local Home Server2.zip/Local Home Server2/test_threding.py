import utilitis
import time
import serial
import requests
import json


serialPort1 = serial.Serial("/dev/ttyACM0", 9600, timeout=0.5)
serialPort2 = serial.Serial("/dev/ttyACM1", 9600, timeout=0.5)
serialPort3 = serial.Serial("/dev/ttyACM2", 9600, timeout=0.5)
serialPort4 = serial.Serial("/dev/ttyACM3", 9600, timeout=0.5)

def testlol():
	try:
		while True:
			command = serialPort2.read_until('\0', size=None)
			commandString = command.decode('utf-8')
			parse = json.loads(commandString)
			if "log" in parse:
				requests.post('http://178.175.250.108:5001/uploud',json = {"type":"logs","row":"{log}, {time}".format(log = parse["log"], time = strftime("%Y-%m-%d %H:%M:%S", gmtime()))})
			requests.post('http://178.175.250.108:5001/uploud',json = {"type":"stats","row":"{data},{time}".format(data = parse["row"], time = strftime("%Y-%m-%d %H:%M:%S", gmtime()))})
			# if len(commandString) > 0:
			# 	print(commandString)

			command = serialPort3.read_until('\0', size=None)
			commandString = command.decode('utf-8')
			if commandString == "1":
			requests.post('http://178.175.250.108:5001/uploud',json = {"type":"logs","row":"'usa garajului sa deschis', {time}".format(time = strftime("%Y-%m-%d %H:%M:%S", gmtime()))})
			if len(utilitis.commands) != 0:
				if "light" in utilitis.commands[-1]:
					to_print = utilitis.commands[-1]["light"].encode("utf-8")
					serialPort1.write(to_print)
					utilitis.commands.pop(-1)
				elif "second" in utilitis.commands[-1]:
					to_print = utilitis.commands[-1]["second"].encode("utf-8")
					serialPort2.write(to_print)
					utilitis.commands.pop(-1)
				elif "garaj" in utilitis.commands[-1]:
					to_print = utilitis.commands[-1]["garaj"].encode("utf-8")
					serialPort3.write(to_print)
					utilitis.commands.pop(-1)
				else:
					print("command not found")

				
	finally:
		print("FUck yo")