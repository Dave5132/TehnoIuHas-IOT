import utilitis
import threading
import test_threding
from flask import Flask
from flask import request
from flask import jsonify



app = Flask(__name__)




@app.route('/')
def general():
	return 'Home Server Used for easy controlling smart Home'

@app.route('/command/<command>')
def coomand_execute(command):
	utilitis.commands.append(command)
	print("From Flask")
	print(utilitis.commands)
	return "Succes"

@app.route('/get_stats')
def get_stats():
	to_send = utilitis.stats
	utilitis.stats.clear()
	return jsonify({"stats": to_send })
	


if __name__ == "__main__":
	try:
		tet = threading.Thread(target=test_threding.testlol)
		tet.start()
		print("thread start")
		app.run(debug=False, port=5000, host='0.0.0.0')
	finally:
		tet.join()
