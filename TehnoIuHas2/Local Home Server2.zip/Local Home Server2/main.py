import threading
import flask_app
import test_threding

def run_Server():
	tet = threading.Thread(target=test_threding.test)
	tet.start()
	print("thread start")
	flask_app.app.run(debug=True, port=5000, host='0.0.0.0')

if __name__ == "__main__":
	run_Server()
