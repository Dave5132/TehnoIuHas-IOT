import serial
import utilitis

serialPort1 = serial.Serial("/dev/ttyUSB0", 9600, timeout=0.5)


try:
    while True:
        command = serialPort1.read_until('\0', size=None)
        commandString = command.decode('utf-8')
        if len(commandString) > 0:
            print(commandString)
        if len(utilitis.commands) != 0 :
            serialPort1.write(utilitis.commands[-1].encode("utf-8"))